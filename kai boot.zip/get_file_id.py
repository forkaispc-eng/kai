import telebot
from config import BOT_TOKEN  # Tokenni config.py dan oladi

bot = telebot.TeleBot(BOT_TOKEN)

@bot.message_handler(content_types=['video','file'])
def get_file_id(message):
    print("✅ file_id:", message.video.file_id)
    bot.reply_to(message, f"✅ file_id: {message.video.file_id}")

bot.polling()
print(get_file_id)