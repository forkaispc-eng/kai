import telebot
from telebot.types import InlineKeyboardMarkup, InlineKeyboardButton
from config import BOT_TOKEN

bot = telebot.TeleBot(BOT_TOKEN)

# Kanal chat_id'lari (kanalga bot admin bo‘lishi shart!)
REQUIRED_CHANNELS = [
    -1002540877698,
    -1002585752194,  # Kanal ID
]

# Kanal linklari (foydalanuvchiga ko‘rsatish uchun)
CHANNEL_LINKS = [
    "https://t.me/+m2Iv68pf2iYzZmIy",
    "https://t.me/+aE2Ou1KU2LI3MTcy",
]

# ❗️ So‘rov yuborgan user_id larini saqlash uchun
pending_requests = set()


# So‘rov yuborishni ushlash
@bot.chat_join_request_handler(func=lambda req: True)
def join_request(req):
    user_id = req.from_user.id
    chat_id = req.chat.id
    pending_requests.add(user_id)  # foydalanuvchini ro‘yxatga qo‘shamiz
    print(f"{user_id} foydalanuvchi {chat_id} kanaliga so‘rov yubordi")


# Obuna tekshiruvi (azo bo‘lgan yoki so‘rov yuborgan)
def is_user_subscribed(user_id):
    for channel_id in REQUIRED_CHANNELS:
        try:
            status = bot.get_chat_member(channel_id, user_id).status
            if status in ['member', 'administrator', 'creator']:
                return True  # ✅ kanalga azo
            elif user_id in pending_requests:
                return True  # ✅ so‘rov yuborgan
            else:
                return False
        except Exception as e:
            print(f"Xatolik: {e}")
            return False
    return False


# Start komandasi
@bot.message_handler(commands=['start'])
def start(message):
    markup = InlineKeyboardMarkup()
    for i, link in enumerate(CHANNEL_LINKS, start=1):
        markup.add(InlineKeyboardButton(f"{i}- KANAL", url=link))
    markup.add(InlineKeyboardButton("✅ Tekshirish", callback_data="check_subs"))
    bot.send_message(
        message.chat.id,
        "❗️ Botdan foydalanishdan oldin kanalga obuna bo‘ling yoki so‘rov yuboring va 'Tekshirish' tugmasini bosing!",
        reply_markup=markup
    )


# Tekshirish tugmasi
@bot.callback_query_handler(func=lambda call: call.data == "check_subs")
def check_subs(call):
    user_id = call.from_user.id
    if is_user_subscribed(user_id):
        bot.send_message(call.message.chat.id, "✅ Obuna/so‘rov tasdiqlandi!\nEndi kodni yuboring:")
    else:
        bot.send_message(call.message.chat.id, "❌ Siz hali kanalga obuna bo‘lmagansiz yoki so‘rov yubormagansiz!")

# Kod orqali kino yuborish
movies = {
    "1": {
        "videos": [
            {
                "file_id": "BAACAgEAAxkBAAIBI2hdgUCIJB1sYwojwHfQH0YVUCfYAAIHBAACd88hR3MDIWIRulzMNgQ",
                "caption": "🎬 Kod: 1\nKINO:Harry Potter hikmatlar toshi Qism: 1/9"
            },
            {
                "file_id": "BAACAgEAAxkBAAIBIWhdgRYeXsqag9oRTu4U5Up5wBzgAAJkAwACGwEoR0YUJaloMswMNgQ",
                "caption": "🎬 Kod: 1\nKINO:Harry Potter Maxfiy hujra Qism: 2/9"
            },
            {
                "file_id": "BAACAgEAAxkBAAIBRWhdjOS6X4pJljGFTYaq4jzzMhU3AAIJAwACLBtoRxip83K7LHR6NgQ",
                "caption": "🎬 Kod: 1\nKINO:Harry Potter Azkaban mahbusi Qism: 3/9"
            },
            {
                "file_id": "BAACAgEAAxkBAAIBR2hdjPPXhybc67ChGNo9l6XPaxEUAAJeAwAC-XmZR9ScgPpHDmhlNgQ",
                "caption": "🎬 Kod: 1\nKINO:Harry Potter Alanga kubogi Qism: 4/9"
            },
            {
                "file_id": "BAACAgEAAxkBAAIBSWhdjQFKvjK4MuLZqSbNjBow4SkFAAIJBAAC0IEAAURx3X9TNZBpeDYE",
                "caption": "🎬 Kod: 1\nKINO:Harry Potter Feniks jamiyati Qism: 5/9"
            },
            {
                "file_id": "BAACAgEAAxkBAAIBS2hdjSjNujg7dT9amXDYDOXjLjKxAAL4BAACdXIoRP2H6z3Z0cniNgQ",
                "caption": "🎬 Kod: 1\nKINO:Harry Potter Tilsim shahzodasi Qism: 6/9"
            },
            {
                "file_id": "BAACAgEAAxkBAAIBTWhdjTjNXeRN9cuF0sUCJBvZcm5DAALeAwACjuhYRCp2BBKDh53INgQ",
                "caption": "🎬 Kod: 1\nKINO:Harry Potter Ajal tuhfalari 1 Qism: 7/9"
            },
            {
                "file_id": "BAACAgEAAxkBAAIBT2hdjUQhAXiwEjd2OCOXW8lGiLnyAAI3AwACjuhgRNSRupuX5pNFNgQ",
                "caption": "🎬 Kod: 1\nKINO:Harry Potter Ajal tuhfalari 2 Qism: 8/9"
            },
            {
                "file_id": "BAACAgQAAxkBAAIBUWhdjU6T17x8wsNBTIr1UM9qmb5BAAIrFwAC-N8hUk-T1oh6wvsaNgQ",
                "caption": "🎬 Kod: 1\nKINO:Harry Potterning 20 yilligi: Xogvartsga qaytish Qism: 9/9"
            }
        ]
    },
"2": {
        "videos": [
            {
                "file_id": "BAACAgUAAxkBAAIBsmipjb6th0meoev5HaBXOtGgpTQZAAImDQACFg0IVZL6-XoObZ3tNgQ",
                "caption": "🎬 Kod: 2\nKINO: Dune 460p Qism: 1/2"
            },
            {
                "file_id": "BAACAgIAAxkBAAIBtWipkMdet2H_qgcQlIM6EMxOI5j5AAIgaQACuurRSofop3hfY-PVNgQ",
                "caption": "🎬 Kod: 2\nKINO: Dune 1080p Qism: 2/2"
            },
        ]
    },

"3": {
        "videos": [
            {
                "file_id": "BAACAgIAAxkBAAIB9miq7YhQOKyD34WD6GLlQ2amGoVHAAIiaQACSzhhSg8tYBnQjmAMNgQ",
                "caption": "🎬 Kod: 3\n📺 Sifat: 1080p\n🎞 Qism: 1/2\n🎥 KINO: Nezha / Neja"
            },
            {
                "file_id": "BAACAgIAAxkBAAIB-Giq7aXWW5GiB2aI6UVsdZq0zEfZAAJzXQACUwnwSW173v4lNFXmNgQ",
                "caption": "🎬 Kod: 3\n📺 Sifat: 1080p\n🎞 Qism: 2/2\n🎥 KINO: Nezha / Neja"
            }
        ]
    },
"4": {
        "videos": [
            {
                "file_id": "BAACAgIAAxkBAAICKGir6lJTF2ShPf-huBP1TTPloR7GAAKqbAACHQrYSqtLZgV43Z6xNgQ",
                "caption": "🎬 Kod: 4\n📺 Sifat: 1080p\n🎞 Qism: 1/1\n🎥 KINO: K-POP Iblis ovchilari"
            },
        ]
    },
    "5": {
        "videos": [
            {
                "file_id": "BAACAgIAAxkBAAIDBWiso32TJNJx8hYE6E0LKWaSPv_zAAIDMwAC01OQSPKNcTcIt_f6NgQ",
                "caption": "🎬 Kod: 5\n📺 Sifat: 1080p\n🎞 Qism: 1/1\n🎥 KINO: Terabitiya ko'prigi"
            },
        ]
    },
    "6": {
        "videos": [
            {
                "file_id": "BAACAgQAAxkBAAIDF2itTsHfVJLTsY7h1FJLSwaM_ry0AAKGCwACmPYgUsAOQxcD987TNgQ",
                "caption": "🎬 Kod: 6\n📺 Sifat: 460p\n🎞 Qism: 1/1\n🎥 KINO: Tokyo drift"
            },
        ]
    },
    "7": {
        "videos": [
            {
                "file_id": "BAACAgQAAxkBAAIDnWivMRduPHk4riAP9JbmAAFQRcJr3QACxwoAAkhbuVCySHvJtCBiWDYE",
                "caption": "🎬 Kod: 7\n📺 Sifat: 720p\n🎞 Qism: 1/1\n🎥 KINO: Vijdon amri"
            },
        ]
    },
    "8": {
        "videos": [
            {
                "file_id": "BAACAgIAAxkBAAIEwmiv5nI-4Xpj3Wo5griiZ0UiMrHpAALBCwACMeO4S3iNU-Xy_JivNgQ",
                "caption": "🎬 Kod: 8\n📺 Sifat: 720p\n🎞 Qism: 1/3\n🎥 KINO: Ajdar o'rgatuvchilari"
            },
            {
                "file_id": "BAACAgIAAxkBAAIEvmiv5jiaF2C0MQdRDi9fLrBR_1nHAAKhCAAC_ERBSbh4hGVy6KfiNgQ",
                "caption": "🎬 Kod: 8\n📺 Sifat: 720p\n🎞 Qism: 2/3\n🎥 KINO: Ajdar o'rgatuvchilari"
            },
            {
                "file_id": "BAACAgQAAxkBAAIEwGiv5lRba30s41E-rgm9cfC___kaAAJDCgAC3SyhUdLNyo0JpzSgNgQ",
                "caption": "🎬 Kod: 8\n📺 Sifat: 720p\n🎞 Qism: 3/3\n🎥 KINO: Ajdar o'rgatuvchilari"
            },
        ]
    },
    "9": {
        "videos": [
            {
                "file_id": "BAACAgUAAxkBAAIFj2iwqBP7XnrbmnRjtL9StCVS55qyAAIPDQACdhy4VQZWEdAXCbhFNgQ",
                "caption": "🎬 Kod: 9\n📺 Sifat: 1080p\n🎞 Qism: 1/2\n🎥 KINO: Jonli polat"
            },
            {
                "file_id": "BAACAgEAAxkBAAIFkGiwqBO3ArmP8MDS6lBniTuunJ6uAAIFBAACTfUAAUakDSQLUcClVjYE",
                "caption": "🎬 Kod: 9\n📺 Sifat: 1080p\n🎞 Qism: 2/2\n🎥 KINO: Jonli polat"
            },
        ]
    },
    "10": {
        "videos": [
            {
                "file_id": "BAACAgEAAxkBAAIF6GixM98X_NlUg0agsHg4RfIOusQCAAJzAAOITflEBX3KjAbxMuQ2BA",
                "caption": "🎬 Kod: 10\n📺 Sifat: 720p\n🎞 Qism: 1/4\n🎥 KINO: Kung fu panda"
            },
            {
                "file_id": "BAACAgEAAxkBAAIF6WixM98Fb-4Ddk8o5bE-qbBVG8qkAALsAAMjJfhExP9xcDco4PI2BA",
                "caption": "🎬 Kod: 10\n📺 Sifat: 720p\n🎞 Qism: 2/4\n🎥 KINO: Kung fu panda"
            },
            {
                "file_id": "BAACAgEAAxkBAAIF6mixM98_jaEQMgeoy4Gz2RAaNgABzAAChgADP54BRcvtEhphHRsyNgQ",
                "caption": "🎬 Kod: 10\n📺 Sifat: 720p\n🎞 Qism: 3/4\n🎥 KINO: Kung fu panda"
            },
            {
                "file_id": "BAACAgQAAxkBAAIF52ixM9_dfdaEEVX9mTS6ZHv_vTBIAAJuFwACYaeYUeB8rOhwL0EhNgQ",
                "caption": "🎬 Kod: 10\n📺 Sifat: 720p\n🎞 Qism: 4/4\n🎥 KINO: Kung fu panda"
            },
        ]
    },
    "11": {
        "videos": [
            {
                "file_id": "BAACAgEAAxkBAAIF9GixOEK3kFdfvWqAcLeJJXsTQ32HAAKKAAOGRFhHm-YNpwd3Eug2BA",
                "caption": "🎬 Kod: 11\n📺 Sifat: 720p\n🎞 Qism: 1/3\n🎥 KINO: Sonic"
            },
            {
                "file_id": "BAACAgQAAxkBAAIF9mixOFAWqvQYnkjOlfMIh6EkuTz7AALAFgACRzpQUyziuw8v8A_sNgQ",
                "caption": "🎬 Kod: 11\n📺 Sifat: 720p\n🎞 Qism: 2/3\n🎥 KINO: Sonic"
            },
            {
                "file_id": "BAACAgQAAxkBAAIF3mixMdbdb1bOIk-cwe3w9TjUHiYNAALNEwACEGYwUwt2XYqge9ciNgQ",
                "caption": "🎬 Kod: 11\n📺 Sifat: 720p\n🎞 Qism: 3/3\n🎥 KINO: Sonic"
            },
        ]
    },
    "12": {
        "videos": [
            {
                "file_id": "BAACAgQAAxkBAAIF_mixOd3TQh32BjFukd0YsjPYIOJQAAMbAAL6IDBRr52P7l4K57w2BA",
                "caption": "🎬 Kod: 12\n📺 Sifat: 720p\n🎞 Qism: 1/4\n🎥 KINO: Mahluqlar tatilda"
            },
            {
                "file_id": "BAACAgIAAxkBAAIGAAFosTnoaT9ne09ksuzwlDQPjyQCxAACj1IAAv4L4UtuO58tCl7zFzYE",
                "caption": "🎬 Kod: 12\n📺 Sifat: 720p\n🎞 Qism: 2/4\n🎥 KINO: Mahluqlar tatilda"
            },
            {
                "file_id": "BAACAgQAAxkBAAIGAmixOfK3_voLCCursHnxaMkeMXs1AALcGgAC-iAwUQJA7Kl6gQ7ZNgQ",
                "caption": "🎬 Kod: 12\n📺 Sifat: 720p\n🎞 Qism: 3/4\n🎥 KINO: Mahluqlar tatilda"
            },
            {
                "file_id": "BAACAgIAAxkBAAIGBGixOgRRZVegQqGcBzxztEBpvzy9AAI4KQACty_5Sexv5kANkPUWNgQ",
                "caption": "🎬 Kod: 12\n📺 Sifat: 720p\n🎞 Qism: 4/4\n🎥 KINO: Mahluqlar tatilda"
            },
        ]
    },
    "13": {
        "videos": [
            {
                "file_id": "BAACAgEAAxkBAAIGM2ixzXz3UQABO3cjohO3s_fj8xj3wQACSAMAAg8UGUd9zk4zlqpuxDYE",
                "caption": "🎬 Kod: 13\n📺 Sifat: 720p\n🎞 Qism: 1/3\n🎥 KINO: Chaqmoq makvin"
            },
            {
                "file_id": "BAACAgEAAxkBAAIGOmixzkWeSB481Sx_wEAbha7_tGSQAAIYBAACxxIZRxxdCyZXzReaNgQ",
                "caption": "🎬 Kod: 13\n📺 Sifat: 720p\n🎞 Qism: 2/3\n🎥 KINO: Chaqmoq makvin"
            },
            {
                "file_id": "BAACAgEAAxkBAAIGPGixzlzwyhZBmkyBMo8FWEClOy0HAAIXBAACxxIZR1Wh3j46tFYRNgQ",
                "caption": "🎬 Kod: 13\n📺 Sifat: 720p\n🎞 Qism: 3/3\n🎥 KINO: Chaqmoq makvin"
            },
        ]
    },
    "14": {
        "videos": [
            {
                "file_id": "BAACAgEAAxkBAAIGQGixz3AIl63eEArvxwht-ZPKLW2jAAKHAQACpDf5RQAB0r6AbUjC6DYE",
                "caption": "🎬 Kod: 14\n📺 Sifat: 460p\n🎞 Qism: 1/2\n🎥 KINO: Muz yurak"
            },
            {
                "file_id": "BAACAgEAAxkBAAIGQmixz3gnhHSPNPaXfu8plmJEXW5kAAJKAQACpDcBRs1YEZAT_KofNgQ",
                "caption": "🎬 Kod: 14\n📺 Sifat: 720p\n🎞 Qism: 2/2\n🎥 KINO: Muz yurak"
            },
        ]
    },
    "15": {
        "videos": [
            {
                "file_id": "BAACAgIAAxkBAAIGRGix0HWGEuLT8ZM93IuSRB5TI8nzAAJNHwAC-Q8pSLLVTgwTua5_NgQ",
                "caption": "🎬 Kod: 15\n📺 Sifat: 720p\n🎞 Qism: 1/2\n🎥 KINO: Ninza toshbaqalar"
            },
            {
                "file_id": "BAACAgIAAxkBAAIGRmix0H6HJ6ZIVNsnUPIkjt1KQXf1AAJXHwAC-Q8pSOyhjV9pcWIVNgQ",
                "caption": "🎬 Kod: 15\n📺 Sifat: 720p\n🎞 Qism: 2/2\n🎥 KINO: Ninza toshbaqalar"
            },
        ]
    },
    "16": {
        "videos": [
            {
                "file_id": "BAACAgEAAxkBAAIGSWix0U_Ds-ONQLq4pZoimrdko2NjAALhAgACVIKhR_UPz46gsFf2NgQ",
                "caption": "🎬 Kod: 16\n📺 Sifat: 1080p\n🎞 Qism: 1/2\n🎥 KINO: Megaladon"
            },
            {
                "file_id": "BAACAgEAAxkBAAIGS2ix0VgsSf88UdPYTzr85mX_Ewk5AAIrBAAC3u2oR2LnZdPEJ9SSNgQ",
                "caption": "🎬 Kod: 16\n📺 Sifat: 1080p\n🎞 Qism: 2/2\n🎥 KINO: Megaladon"
            },
        ]
    },
    "17": {
        "videos": [
            {
                "file_id": "BAACAgEAAxkBAAIGvWi4PcChCTpGSoRg_OaWPJ_aBiq4AAIoAgACHs6YR0R4uDZOlhTQNgQ",
                "caption": "🎬 Kod: 17\n📺 Sifat: 1080p\n🎞 Qism: 1/1\n🎥 KINO: Josus do'stlar'"
            },
        ]
    },
    "18": {
        "videos": [
            {
                "file_id": "BAACAgIAAxkBAAIHF2i53U_FLgjZz626Ceb-Zj56aANlAAJQBQACu5ZBSOUdV9Yw3GGKNgQ",
                "caption": "🎬 Kod: 18\n📺 Sifat: 720p\n🎞 Qism: 1/3\n🎥 KINO: Madagaskar"
            },
            {
                "file_id": "BAACAgIAAxkBAAIHGWi53VNtscrGE1V9s_uaoXr0CE9GAAJIBQACN9VJSEfCjdkkRZGMNgQ",
                "caption": "🎬 Kod: 18\n📺 Sifat: 720p\n🎞 Qism: 2/3\n🎥 KINO: Madagaskar"
            },
            {
                "file_id": "BAACAgIAAxkBAAIHG2i53Ve84swv6jQXGCyVBsnWSvCCAAKPDgACbgpwSL8plq7_Uh8lNgQ",
                "caption": "🎬 Kod: 18\n📺 Sifat: 720p\n🎞 Qism: 3/3\n🎥 KINO: Madagaskar"
            },
        ]
    },
    "19": {
        "videos": [
            {
                "file_id": "BAACAgQAAxkBAAIHHWi53etzKN1iRvOSmMKtA9N4NUhQAALgFwACzy75U5gPMmWgIuJJNgQ",
                "caption": "🎬 Kod: 19\n📺 Sifat: 720p\n🎞 Qism: 1/1\n🎥 KINO: Karatechi bola"
            },
        ]
    },
    "20": {
        "videos": [
            {
                "file_id": "BAACAgQAAxkBAAIHH2i53lI9QMWWF8ucCZiN7yxCDcG7AALhGAACYrdhUvI0RVSIDh8lNgQ",
                "caption": "🎬 Kod: 20\n📺 Sifat: 1080p\n🎞 Qism: 1/1\n🎥 KINO: Poygachi herbi"
            },
        ]
    },
    "21": {
        "videos": [
            {
                "file_id": "BAACAgQAAxkBAAIHI2i53zvslHyzxdlg1Zhr4Rayo2AEAAJdEwACU1yBUg32I2wzH74VNgQ",
                "caption": "🎬 Kod: 21\n📺 Sifat: 1080p\n🎞 Qism: 1/1\n🎥 KINO: Ijtimoiy tarmoq"
            },
        ]
    },
    "22": {
        "videos": [
            {
                "file_id": "BAACAgIAAxkBAAIHJWi53-ixUmoEs2W3eGmhxVZ79BfWAAKlOAACzB7hSbvsbjZBUeRlNgQ",
                "caption": "🎬 Kod: 22\n📺 Sifat: 1080p\n🎞 Qism: 1/2\n🎥 KINO: Boshqotirma"
            },
            {
                "file_id": "BAACAgQAAxkBAAIHJ2i53-7cQHDWkHKOLlPd1AmxQIieAAK2FwACylwIU-Z1BhhhCvQJNgQ",
                "caption": "🎬 Kod: 22\n📺 Sifat: 1080p\n🎞 Qism: 2/2\n🎥 KINO: Boshqotirma"
            },
        ]
    },
    "23": {
        "videos": [
            {
                "file_id": "BAACAgQAAxkBAAIHK2i54ESeKMv0GU8vRkWhz5rpB4B-AAIkCAACR_PBUk7PJvUVmJUxNgQ",
                "caption": "🎬 Kod: 23\n📺 Sifat: 1080p\n🎞 Qism: 1/7\n🎥 KINO: Muzlik davri"
            },
            {
                "file_id": "BAACAgQAAxkBAAIHLWi54Ergxh9fJVDO8RZIuJENZspxAALiCAACX1nQUrwoW20M04iRNgQ",
                "caption": "🎬 Kod: 23\n📺 Sifat: 1080p\n🎞 Qism: 2/7\n🎥 KINO: Muzlik davri"
            },
            {
                "file_id": "BAACAgQAAxkBAAIHL2i54FDblhLg0UZgad91JqM3kcqmAAKKBwACU-PgUtLr6KSefe2dNgQ",
                "caption": "🎬 Kod: 23\n📺 Sifat: 1080p\n🎞 Qism: 3/7\n🎥 KINO: Muzlik davri"
            },
            {
                "file_id": "BAACAgQAAxkBAAIHMWi54FXhDQ4rRcA2kDnfYQ9-DGSZAAIECAACU-PoUvii08A5QcbZNgQ",
                "caption": "🎬 Kod: 23\n📺 Sifat: 1080p\n🎞 Qism: 4/7\n🎥 KINO: Muzlik davri"
            },
            {
                "file_id": "BAACAgQAAxkBAAIHM2i54Fv0_EGruIceoqGIDe79djGoAAIECAACy90JUztYTK_lkurONgQ",
                "caption": "🎬 Kod: 23\n📺 Sifat: 1080p\n🎞 Qism: 5/7\n🎥 KINO: Muzlik davri"
            },
            {
                "file_id": "BAACAgEAAxkBAAIHNWi54GEa8D2iQm4Fim8LI_0eUblUAAKYAwACXzG5RwABAcVIXC1dODYE",
                "caption": "🎬 Kod: 23\n📺 Sifat: 1080p\n🎞 Qism: 6/7\n🎥 KINO: Muzlik davri"
            },
            {
                "file_id": "BAACAgEAAxkBAAIHN2i54GarJwIwMUQXynWes0Jz1NHdAAJVAQACH0DoRcrKiix7cwlUNgQ",
                "caption": "🎬 Kod: 23\n📺 Sifat: 1080p\n🎞 Qism: 7/7\n🎥 KINO: Muzlik davri  Yangi yil"
            },
        ]
    },
    "24": {
        "videos": [
            {
                "file_id": "BAACAgQAAxkBAAIHOWi54MejqPRLzYpJN_BoZfp1HcjfAAI4FwACSLgQUYsaqeegd0f6NgQ",
                "caption": "🎬 Kod: 24\n📺 Sifat: 1080p\n🎞 Qism: 1/1\n🎥 KINO: O'pishish honasi"
            },
        ]
    },
    "25": {
        "videos": [
            {
                "file_id": "BAACAgEAAxkBAAIHO2i54f8a0Jcp9yoeL2KwGX-u7OqFAAK8AAN8LqhEp0ypHumuges2BA",
                "caption": "🎬 Kod: 25\n📺 Sifat: 1080p\n🎞 Qism: 1/1\n🎥 KINO: Qahramonlar shahri"
            },
        ]
    },
    "26": {
        "videos": [
            {
                "file_id": "BAACAgEAAxkBAAIHPWi54t9Gzycqohe4NDerWDPN3GiWAAI4AgACVw8RRgnI_sp9toMbNgQ",
                "caption": "🎬 Kod: 26\n📺 Sifat: 1080p\n🎞 Qism: 1/1\n🎥 KINO: Yangi mutantlar"
            },
        ]
    },
    "27": {
        "videos": [
            {
                "file_id": "BAACAgQAAxkBAAIHQWi54-8W-bWfIOED4I_Cee38_FQYAAIIFwACLWCZU7HhkI14Pj2oNgQ",
                "caption": "🎬 Kod: 27\n📺 Sifat: 1080p\n🎞 Qism: 1/1\n🎥 KINO: Minecraft"
            },
        ]
    },
    "28": {
        "videos": [
            {
                "file_id": "BAACAgIAAxkBAAIHQ2i55LbOB8OYeQPaBKJ7AAFPttZ3fQACEnkAAgsOsEjT1e24K3N-dTYE",
                "caption": "🎬 Kod: 28\n📺 Sifat: 720p\n🎞 Qism: 1/1\n🎥 KINO: Mehr hududi"
            },
        ]
    },
    "29": {
        "videos": [
            {
                "file_id": "BAACAgEAAxkBAAIHRWi55uQ2A6_JqocFHNvlbd2O54YHAAJ7AwACz7VJRXAOdIl1SypgNgQ",
                "caption": "🎬 Kod: 29\n📺 Sifat: 1080p\n🎞 Qism: 1/1\n🎥 KINO: Asoschi"
            },
        ]
    },
    "30": {
        "videos": [
            {
                "file_id": "BAACAgQAAxkBAAIIjGi9Ip_tkX8VHU5-cullOXdfdTu4AAKyGQAC9QGhUAEmUoddKwa8NgQ",
                "caption": "🎬 Kod: 30\n📺 Sifat: 1080p\n🎞 Qism: 1/8\n🎥 KINO: Wednesday"
            },
            {
                "file_id": "BAACAgQAAxkBAAIIjmi9IqSkzcdPiqbFIEL8H4NOgzJzAALnGQAC9QGhUN-K79FZtvgFNgQ",
                "caption": "🎬 Kod: 30\n📺 Sifat: 1080p\n🎞 Qism: 2/8\n🎥 KINO: Wednesday"
            },
            {
                "file_id": "BAACAgQAAxkBAAIIkGi9Iql3eGhP1H9UZKJibpu9KuyjAAJYGgAC9QGhUHv437eIhXA0NgQ",
                "caption": "🎬 Kod: 30\n📺 Sifat: 1080p\n🎞 Qism: 3/8\n🎥 KINO: Wednesday"
            },
            {
                "file_id": "BAACAgQAAxkBAAIIkmi9Iq0hTn9BNosymVkDeg7hJ49pAALEGgAC9QGhUNIJF7YD8uChNgQ",
                "caption": "🎬 Kod: 30\n📺 Sifat: 1080p\n🎞 Qism: 4/8\n🎥 KINO: Wednesday"
            },
            {
                "file_id": "BAACAgQAAxkBAAIIlGi9IrJoS42A4ivUC0SaKyZKqLPFAAKqGgACOkjIUUMAAavJertFUzYE",
                "caption": "🎬 Kod: 30\n📺 Sifat: 1080p\n🎞 Qism: 5/8\n🎥 KINO: Wednesday"
            },
            {
                "file_id": "BAACAgIAAxkBAAIIlmi9IrejsHXXOBUa-BuA_NpK-Sh5AAJirQACp6LBSV-YVt9bgrEfNgQ",
                "caption": "🎬 Kod: 30\n📺 Sifat: 1080p\n🎞 Qism: 6/8\n🎥 KINO: Wednesday"
            },
            {
                "file_id": "BAACAgIAAxkBAAIImGi9IrtmLWI0rfZ4fNLzZLjd4dQXAALidAACp6LJSaPPrZDxqZmENgQ",
                "caption": "🎬 Kod: 30\n📺 Sifat: 1080p\n🎞 Qism: 7/8\n🎥 KINO: Wednesday"
            },
            {
                "file_id": "BAACAgIAAxkBAAIImmi9Ir_4y21PSq-XycoVAiKkEJCPAAIqdQACp6LJSa7sjaAoU5kLNgQ",
                "caption": "🎬 Kod: 30\n📺 Sifat: 1080p\n🎞 Qism: 8/8\n🎥 KINO: Wednesday"
            },
        ]
    },
    "31": {
        "videos": [
            {
                "file_id": "BAACAgQAAxkBAAIJKWi_ucieaSc-Es6loqXPi0jYW_aYAAI0EAACeFOxU8kVWFz9E0hoNgQ",
                "caption": "🎬 Kod: 31\n📺 Sifat: 1080p\n🎞 Qism: 1/2\n🎥 KINO: Mening aybim"
            },
            {
                "file_id": "BAACAgQAAxkBAAIJK2i_ueWtcu43CpC6YIe5fPUv_z3zAAKzFwAC0V6gUOQQjvpOfF0BNgQ",
                "caption": "🎬 Kod: 31\n📺 Sifat: 1080p\n🎞 Qism: 2/2\n🎥 KINO: Mening aybim"
            },
        ]
    },
    "32": {
        "videos": [
            {
                "file_id": "BAACAgEAAxkBAAIJM2i_1weW0KCb5HZ4grr2gif4HCyAAALtAgACeXcoRjy9L5wUw-i6NgQ",
                "caption": "🎬 Kod: 32\n📺 Sifat: 1080p\n🎞 Qism: 1/1\n🎥 KINO: Bojhona ruhsat etadi"
            },
        ]
    },
    "33": {
        "videos": [
            {
                "file_id": "BAACAgIAAxkBAAIJNWi_1yC-sBLlQSBi5sxqOD4nO9SQAAIOIwAC3AaBSlXjYSHBdWTnNgQ",
                "caption": "🎬 Kod: 33\n📺 Sifat: 1080p\n🎞 Qism: 1/6\n🎥 KINO: Transformerlar"
            },
            {
                "file_id": "BAACAgIAAxkBAAIJN2i_1ycoVrUmHP1LHiUZ5fUpwx7bAAKrKwAC9p55Sn16aQa69ritNgQ",
                "caption": "🎬 Kod: 33\n📺 Sifat: 1080p\n🎞 Qism: 2/6\n🎥 KINO: Transformerlar"
            },
            {
                "file_id": "BAACAgIAAxkBAAIJOWi_1yyjAAGMhFHyLMFBqi-1VIT-TwACwSYAAlNBgUrHlPrl90enlzYE",
                "caption": "🎬 Kod: 33\n📺 Sifat: 1080p\n🎞 Qism: 3/6\n🎥 KINO: Transformerlar"
            },
            {
                "file_id": "BAACAgIAAxkBAAIJO2i_1zCep2HnzXVvQTqQAtFi7LNQAAJ-IQACzh6BSg9CwmkxT891NgQ",
                "caption": "🎬 Kod: 33\n📺 Sifat: 1080p\n🎞 Qism: 4/6\n🎥 KINO: Transformerlar"
            },
            {
                "file_id": "BAACAgEAAxkBAAIJPWi_1zUjPI2Xb1q0PfM1jusV0O94AAL9AQACX04QR9XJ2idQELMhNgQ",
                "caption": "🎬 Kod: 33\n📺 Sifat: 1080p\n🎞 Qism: 5/6\n🎥 KINO: Transformerlar"
            },
            {
                "file_id": "BAACAgUAAxkBAAIJP2i_1zrb80-_Hlak2gY9K8H5VTi7AAICCgACqMahVaGf2ZaRWRK0NgQ",
                "caption": "🎬 Kod: 33\n📺 Sifat: 1080p\n🎞 Qism: 6/6\n🎥 KINO: Transformerlar"
            },
        ]
    },
    "34": {
        "videos": [
            {
                "file_id": "BAACAgQAAxkBAAIJQWi_12LuGPF8XbXEbil3yX6_rxgKAAJfEwACgJsIUGcziFzYV8cRNgQ",
                "caption": "🎬 Kod: 34\n📺 Sifat: 1080p\n🎞 Qism: 1/1\n🎥 KINO: Orion va zulmat"
            },
        ]
    },
    "35": {
        "videos": [
            {
                "file_id": "BAACAgQAAxkBAAIJQ2i_12ggv4al2Z3bN9SuU5_nOl3VAAIGDgAC-ORAUA7VV6jZ02C0NgQ",
                "caption": "🎬 Kod: 35\n📺 Sifat: 1080p\n🎞 Qism: 1/1\n🎥 KINO: Mehribon devqomat"
            },
        ]
    },
    "36": {
        "videos": [
            {
                "file_id": "BAACAgQAAxkBAAIJRWi_123K5nwbQSQ2MhUqRWRE0_xzAAI6DgAC6zxIU1d9OTu_eUBNNgQ",
                "caption": "🎬 Kod: 36\n📺 Sifat: 1080p\n🎞 Qism: 1/1\n🎥 KINO: Elemental"
            },
        ]
    },
    "37": {
        "videos": [
            {
                "file_id": "BAACAgQAAxkBAAIJR2i_13Iil3-3um6h6FNVJtqX-4hIAAIgFwACaEAYU-4kU8BBlmZNNgQ",
                "caption": "🎬 Kod: 37\n📺 Sifat: 1080p\n🎞 Qism: 1/1\n🎥 KINO: Gipnotik"
            },
        ]
    },
    "38": {
        "videos": [
            {
                "file_id": "BAACAgQAAxkBAAIJSWi_13si8X-McO-iFcUKTi_WNcIEAAJdBwACNoiBUZhX2lhaCQKeNgQ",
                "caption": "🎬 Kod: 38\n📺 Sifat: 1080p\n🎞 Qism: 1/5\n🎥 KINO: Taxi"
            },
            {
                "file_id": "BAACAgQAAxkBAAIJS2i_137qwEp4ozcOd5e1e49etzEPAAJfBwACNoiBUfs7XQhukyz3NgQ",
                "caption": "🎬 Kod: 38\n📺 Sifat: 1080p\n🎞 Qism: 2/5\n🎥 KINO: Taxi"
            },
            {
                "file_id": "BAACAgQAAxkBAAIJTWi_14THNeDsvY7sjjgwx17mXM1JAAJgBwACNoiBUTnRyoi48zEiNgQ",
                "caption": "🎬 Kod: 38\n📺 Sifat: 1080p\n🎞 Qism: 3/5\n🎥 KINO: Taxi"
            },
            {
                "file_id": "BAACAgQAAxkBAAIJT2i_14hM9JF_0bSoUejP9aQd7R1JAAJiBwACNoiBUUAwCJkfKhCtNgQ",
                "caption": "🎬 Kod: 38\n📺 Sifat: 1080p\n🎞 Qism: 4/5\n🎥 KINO: Taxi"
            },
            {
                "file_id": "BAACAgQAAxkBAAIJUWi_14w7VPOfi8d6qp2iuAXCVtJvAAJkBwACNoiBUbsqeICFvgg-NgQ",
                "caption": "🎬 Kod: 38\n📺 Sifat: 1080p\n🎞 Qism: 5/5\n🎥 KINO: Taxi"
            },
        ]
    },
    "39": {
        "videos": [
            {
                "file_id": "BAACAgQAAxkBAAIJU2i_155_cjG0IogOs0T5y1mqR1wGAAIgDQACrXYRURVAkDoEpyw8NgQ",
                "caption": "🎬 Kod: 39\n📺 Sifat: 1080p\n🎞 Qism: 1/1\n🎥 KINO: Kunduzgi Navbatchilik"
            },
        ]
    },
    "40": {
        "videos": [
            {
                "file_id": "BAACAgIAAxkBAAIJVWi_16T8vplbhno-SzMrgICed7vwAALrBwAC23vBS_jFJhn8FcqmNgQ",
                "caption": "🎬 Kod: 40\n📺 Sifat: 1080p\n🎞 Qism: 1/1\n🎥 KINO: Forrest gamp"
            },
        ]
    },
    "41": {
        "videos": [
            {
                "file_id": "BAACAgQAAxkBAAIJV2i_17MUaNm2-orXgYendrQ5Y-5AAALoFgACPUvhURjHLp3ReZl0NgQ",
                "caption": "🎬 Kod: 41\n📺 Sifat: 1080p\n🎞 Qism: 1/1\n🎥 KINO: Yovvoyi robot"
            },
        ]
    },
    "42": {
        "videos": [
            {
                "file_id": "BAACAgQAAxkBAAIJWWi_18XSyn0rKg5HqBYGKKNirHjhAAJyFgAC7dPBUdl1S3DrYdqRNgQ",
                "caption": "🎬 Kod: 42\n📺 Sifat: 1080p\n🎞 Qism: 1/1\n🎥 KINO: Kapitan Amerika 4: Jasur yangi dunyo"
            },
        ]
    },
    "43": {
        "videos": [
            {
                "file_id": "BAACAgEAAxkBAAIJW2i_18qH-09t1QXkSURr5xx04B4hAAJEAQACBeqIRv94FbN6q3aHNgQ",
                "caption": "🎬 Kod: 43\n📺 Sifat: 1080p\n🎞 Qism: 1/4\n🎥 KINO: John Wick"
            },
            {
                "file_id": "BAACAgQAAxkBAAIJXWi_187UK4A4kQmMELE036iX3eLIAAJEDQACh8EIUTr1q38IjqmyNgQ",
                "caption": "🎬 Kod: 43\n📺 Sifat: 1080p\n🎞 Qism: 2/4\n🎥 KINO: John Wick"
            },
            {
                "file_id": "BAACAgQAAxkBAAIJX2i_19KLlYT_DrA8M10AAb36aA4TEQAC9g8AAkDZAAFRnj8hMVqq74A2BA",
                "caption": "🎬 Kod: 43\n📺 Sifat: 1080p\n🎞 Qism: 3/4\n🎥 KINO: John Wick"
            },
            {
                "file_id": "BAACAgQAAxkBAAIJYWi_19Yfi37uuzD8fh8hYrGj5JxQAAJbFQACW_8IUVgrTN_qCbX0NgQ",
                "caption": "🎬 Kod: 43\n📺 Sifat: 1080p\n🎞 Qism: 4/4\n🎥 KINO: John Wick"
            },
        ]
    },
    "44": {
        "videos": [
            {
                "file_id": "BAACAgIAAxkBAAIJY2i_195cKlEm5ljs0Id2Q3M5_TXVAALvRgACvjdoSz3c3NPZ-pyTNgQ",
                "caption": "🎬 Kod: 44\n📺 Sifat: 1080p\n🎞 Qism: 1/2\n🎥 KINO: Ralf"
            },
            {
                "file_id": "BAACAgIAAxkBAAIJZWi_1-I1OTy9lmspUMhHvTrCtWnhAAL5RgACvjdoS_5V5DfQZW_hNgQ",
                "caption": "🎬 Kod: 44\n📺 Sifat: 1080p\n🎞 Qism: 2/2\n🎥 KINO: Ralf"
            },
        ]
    },
        "45": {
        "videos": [
            {
                "file_id": "BAACAgQAAxkBAAIKAWi_6ocIEIakWZ-LV-CGX34RUlxKAAIMCgAC__-gUpisnZr7kPsqNgQ",
                "caption": "🎬 Kod: 45\n📺 Sifat: 1080p\n🎞 Qism: 1/1\n🎥 KINO: Kapitan Amerika 4: Free guy"
            },
        ]
    },
        "46": {
        "videos": [
            {
                "file_id": "BAACAgQAAxkBAAINBGjpxzbue6rL-goIuaDkrd0D0etPAAIzGQACGfxYUYsMvfWaEZn3NgQ",
                "caption": "🎬 Kod: 46\n📺 Sifat: 1080p\n🎞 Qism: 1/1\n🎥 KINO: Hechkim 2"
            },
        ]
    },
        "47": {
        "videos": [
            {
                "file_id": "BAACAgUAAxkBAAINDGjp05KAEbWNWUaOSIte8fypKvkEAAK1EwACbD2hVnKyJRaCwbIINgQ",
                "caption": "🎬 Kod: 47\n📺 Sifat: 1080p\n🎞 Qism: 1/1\n🎥 KINO: Billi Linning hayoti"
            },
        ]
    },
        "48": {
        "videos": [
            {
                "file_id": "BAACAgQAAxkBAAINCmjpz3dlo9xF4LBkFIPTQ9g-GbjqAAILGwACuFQ5UiMT_uICwm0ONgQ",
                "caption": "🎬 Kod: 48\n📺 Sifat: 1080p\n🎞 Qism: 1/1\n🎥 KINO: Tashlandiq odam"
            },
        ]
    },
        "49": {
        "videos": [
            {
                "file_id": "BAACAgIAAxkBAAIOMmkl-7d4yjxYaOHRQWPmUG5-gVXNAAKOWgACLxxBSaZq2phwibnfNgQ",
                "caption": "🎬 Kod: 49\n📺 Sifat: 1080p\n🎞 Qism: 1/1\n🎥 KINO: Puling bo'lsa"
            },
        ]
    },
        "50": {
        "videos": [
            {
                "file_id": "BAACAgIAAxkBAAIONGkl_OMyNCjVffuuVcXel5EKr83VAAJ6hAACWGnYSOlFfnAztUnINgQ",
                "caption": "🎬 Kod: 50\n📺 Sifat: 1080p\n🎞 Qism: 1/1\n🎥 KINO: Qamoq"
            },
        ]
    },
        "51": {
        "videos": [
            {
                "file_id": "BAACAgQAAxkBAAIONmkl_TkZknQ7IXV4YoLNw5I9yYsOAAIUFQACnzlJUEykSrN686AoNgQ",
                "caption": "🎬 Kod: 51\n📺 Sifat: 1080p\n🎞 Qism: 1/1\n🎥 KINO: Jangchi qiruvchi"
            },
        ]
    },
        "52": {
        "videos": [
            {
                "file_id": "BAACAgIAAxkBAAIOOGkl_ZyUPeOC8sH2IAXou_hn6IKuAALZdgACO4zYSC2Uqesq_qCHNgQ",
                "caption": "🎬 Kod: 52\n📺 Sifat: 1080p\n🎞 Qism: 1/1\n🎥 KINO: Lanatlangan dara"
            },
        ]
    },
        "53": {
        "videos": [
            {
                "file_id": "BAACAgQAAxkBAAIOOmkl_en-iuPEMIj3TFFc2Ggq3cwwAAIPEgACoZLYUZ1sTGnjyP6UNgQ",
                "caption": "🎬 Kod: 53\n📺 Sifat: 1080p\n🎞 Qism: 1/1\n🎥 KINO: Asalarichi"
            },
        ]
    },
        "54": {
        "videos": [
            {
                "file_id": "BAACAgQAAxkBAAIOPGkl_kFqQ_dmB1oaZIw3u4ThOcDfAAKnGAACIGm5UPNSWdEEVwjWNgQ",
                "caption": "🎬 Kod: 54\n📺 Sifat: 1080p\n🎞 Qism: 1/1\n🎥 KINO: Xitmen 2"
            },
        ]
    },
        "55": {
        "videos": [
            {
                "file_id": "BAACAgQAAxkBAAIOPmkl_pIuYVbSgWnHkVQP-5DMDdnrAAJbEgAC0b6RU3vkqwH5rz7oNgQ",
                "caption": "🎬 Kod: 55\n📺 Sifat: 1080p\n🎞 Qism: 1/1\n🎥 KINO: Farzand"
            },
        ]
    }
}


@bot.message_handler(func=lambda message: True)
def send_movie(message):
    user_id = message.from_user.id

    if not is_user_subscribed(user_id):
        start(message)
        return

    code = message.text.strip()
    if code in movies:
        videos = movies[code]["videos"]
        for video in videos:
            file_id = video["file_id"]
            caption = video["caption"] + "\n\n👉 Kanal: https://t.me/MyBlackest"
            bot.send_video(message.chat.id, file_id, caption=caption)
    else:
        bot.reply_to(message, "❌ Bunday kodga mos kino topilmadi. Iltimos, to‘g‘ri kod kiriting.")


bot.polling()