import telebot
from config import BOT_TOKEN

bot = telebot.TeleBot(BOT_TOKEN)

@bot.message_handler(commands=['id'])
def send_chat_id(message):
    bot.send_message(message.chat.id, f"Chat ID: {message.chat.id}")

bot.polling()
